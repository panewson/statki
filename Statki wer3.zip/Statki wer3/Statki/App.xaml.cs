﻿using System.Windows;

namespace Statki
{
    public partial class App : Application
    {
    }
}
