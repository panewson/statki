﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Statki.Models;

namespace Statki.Converters
{
    public class CellToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value switch
            {
                CellState.Empty => Brushes.LightBlue,
                CellState.Ship => Brushes.Navy,
                CellState.Hit => Brushes.Red,
                CellState.Miss => Brushes.White,
                CellState.Sunk => Brushes.DarkRed,
                _ => Brushes.Gray
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
    }
}
