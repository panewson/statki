﻿using System.Linq;

namespace Statki.Models
{
    public class Board
    {
        public const int Size = 10;
        public Cell[,] Grid { get; } = new Cell[Size, Size];

        public Board()
        {
            for (int r = 0; r < Size; r++)
                for (int c = 0; c < Size; c++)
                    Grid[r, c] = new Cell { Row = r, Col = c };
        }

        public bool PlaceShip(Ship ship, int row, int col, Direction dir)
        {
            for (int i = 0; i < ship.Length; i++)
            {
                int r = dir == Direction.Horizontal ? row : row + i;
                int c = dir == Direction.Horizontal ? col + i : col;
                if (r >= Size || c >= Size || Grid[r, c].State != CellState.Empty)
                    return false;
            }

            for (int i = 0; i < ship.Length; i++)
            {
                int r = dir == Direction.Horizontal ? row : row + i;
                int c = dir == Direction.Horizontal ? col + i : col;
                ship.Cells[i] = Grid[r, c];
                Grid[r, c].State = CellState.Ship;
                Grid[r, c].OccupiedShip = ship;
            }
            return true;
        }

        public CellState Shoot(int row, int col)
        {
            var cell = Grid[row, col];
            if (cell.State == CellState.Hit || cell.State == CellState.Miss || cell.State == CellState.Sunk)
                return cell.State;

            cell.State = cell.OccupiedShip != null ? CellState.Hit : CellState.Miss;

            if (cell.State == CellState.Hit && cell.OccupiedShip!.IsSunk)
            {
                foreach (var c in cell.OccupiedShip.Cells.Where(x => x != null))
                    c.State = CellState.Sunk;
            }

            return cell.State;
        }

        public bool AllShipsSunk()
        {
            var ships = Grid.Cast<Cell>().Where(c => c.OccupiedShip != null).Select(c => c.OccupiedShip).Distinct();
            return ships.Any() && ships.All(s => s != null && s.IsSunk);
        }
    }
}