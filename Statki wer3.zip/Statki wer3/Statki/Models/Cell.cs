﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Statki.Models
{
    public enum CellState
    {
        Empty,
        Ship,
        Hit,
        Miss,
        Sunk
    }

    public class Cell : INotifyPropertyChanged
    {
        private int _row;
        private int _col;
        private CellState _state = CellState.Empty;
        private Ship? _occupiedShip;

        public int Row
        {
            get => _row;
            set => SetProperty(ref _row, value);
        }

        public int Col
        {
            get => _col;
            set => SetProperty(ref _col, value);
        }

        public CellState State
        {
            get => _state;
            set => SetProperty(ref _state, value);
        }

        public Ship? OccupiedShip
        {
            get => _occupiedShip;
            set => SetProperty(ref _occupiedShip, value);
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            return true;
        }
    }
}
