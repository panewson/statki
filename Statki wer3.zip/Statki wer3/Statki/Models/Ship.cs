﻿using System.Linq;

namespace Statki.Models
{
    public enum ShipType
    {
        Destroyer = 2,
        Cruiser = 3,
        Battleship = 4,
        Carrier = 5
    }

    public enum Direction
    {
        Horizontal,
        Vertical
    }

    public class Ship
    {
        public ShipType Type { get; }
        public int Length => (int)Type;
        public Cell[] Cells { get; }

        public bool IsSunk => Cells.Length > 0 && Cells.All(c => c != null && (c.State == CellState.Hit || c.State == CellState.Sunk));

        public Ship(ShipType type)
        {
            Type = type;
            Cells = new Cell[Length];
        }
    }
}
