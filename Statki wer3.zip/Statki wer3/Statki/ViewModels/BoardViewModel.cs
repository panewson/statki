﻿using CommunityToolkit.Mvvm.ComponentModel;
using Statki.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace Statki.ViewModels
{
    public partial class BoardViewModel : ObservableObject
    {
        public Board Board { get; } = new Board();
        public ObservableCollection<Cell> Grid { get; } = new ObservableCollection<Cell>();
        public Cell[] GridFlattened => Grid.ToArray();

        public BoardViewModel()
        {
            for (int r = 0; r < Board.Size; r++)
                for (int c = 0; c < Board.Size; c++)
                    Grid.Add(Board.Grid[r, c]);
        }

        public void PlaceRandomShips(bool revealShips = true)
        {
            var random = new Random();
            var shipTypes = new[] { ShipType.Carrier, ShipType.Battleship, ShipType.Cruiser, ShipType.Destroyer };

            foreach (var shipType in shipTypes)
            {
                bool placed = false;
                while (!placed)
                {
                    int row = random.Next(Board.Size);
                    int col = random.Next(Board.Size);
                    Direction dir = random.Next(2) == 0 ? Direction.Horizontal : Direction.Vertical;
                    
                    var ship = new Ship(shipType);
                    placed = Board.PlaceShip(ship, row, col, dir);
                }
            }
            if (!revealShips)
            {
                foreach (var cell in Grid.Where(c => c.OccupiedShip != null))
                    cell.State = CellState.Empty;
                OnPropertyChanged(nameof(Grid));
            }
        }

        public bool PlaceShip(Ship ship, int row, int col, Direction dir)
        {
            var placed = Board.PlaceShip(ship, row, col, dir);
            OnPropertyChanged(nameof(Grid));
            return placed;
        }

        public CellState Shoot(int row, int col)
        {
            var result = Board.Shoot(row, col);
            OnPropertyChanged(nameof(Grid));
            return result;
        }
    }
}
