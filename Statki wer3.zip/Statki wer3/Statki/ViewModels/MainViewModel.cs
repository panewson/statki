﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Statki.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System;
using System.Linq;
using Statki.Models;

namespace Statki.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty] private BoardViewModel playerBoard;
        [ObservableProperty] private BoardViewModel enemyBoard;
        [ObservableProperty] private bool playerTurn = true;
        [ObservableProperty] private string status = "Rozmieść statki na swojej planszy";
        [ObservableProperty] private bool gameOver = false;

        private readonly ShipType[] _placementOrder = new[] { ShipType.Carrier, ShipType.Battleship, ShipType.Cruiser, ShipType.Destroyer };
        private int _nextShipIndex = 0;
        private Direction _placementDirection = Direction.Horizontal;

        public MainViewModel()
        {
            PlayerBoard = new BoardViewModel();
            EnemyBoard = new BoardViewModel();
            EnemyBoard.PlaceRandomShips(revealShips: false);
        }

        [RelayCommand]
        public void NewGame()
        {
            PlayerBoard = new BoardViewModel();
            EnemyBoard = new BoardViewModel();
            EnemyBoard.PlaceRandomShips(revealShips: false);

            _nextShipIndex = 0;
            _placementDirection = Direction.Horizontal;
            PlayerTurn = true;
            GameOver = false;
            Status = "Rozmieść statki na swojej planszy";
        }

        [RelayCommand]
        public async Task CellClickedAsync(Cell cell)
        {
            if (GameOver) return;

            if (cell is null) return;

            if (PlayerBoard.GridFlattened.Contains(cell))
            {
                if (_nextShipIndex >= _placementOrder.Length)
                {
                    Status = "Wszystkie statki rozmieszczone.";
                    return;
                }

                var ship = new Ship(_placementOrder[_nextShipIndex]);
                bool placed = PlayerBoard.PlaceShip(ship, cell.Row, cell.Col, _placementDirection);

                if (!placed)
                {
                    var alt = _placementDirection == Direction.Horizontal ? Direction.Vertical : Direction.Horizontal;
                    if (PlayerBoard.PlaceShip(ship, cell.Row, cell.Col, alt))
                    {
                        placed = true;
                        _placementDirection = alt;
                    }
                }

                if (!placed)
                {
                    Status = "Nie można umieścić statku, spróbuj gdzie indziej.";
                    return;
                }

                _nextShipIndex++;
                if (_nextShipIndex >= _placementOrder.Length)
                    Status = "Rozmieszczono wszystkie statki. Możesz zaczynać strzelać!";
                else
                    Status = $"Umieszczono statek. Pozostało: {_placementOrder.Length - _nextShipIndex}";

                return;
            }

            if (EnemyBoard.GridFlattened.Contains(cell) && PlayerTurn && _nextShipIndex >= _placementOrder.Length)
            {
                var result = EnemyBoard.Shoot(cell.Row, cell.Col);
                Status = result switch
                {
                    CellState.Hit => "Trafienie!",
                    CellState.Miss => "Pudło!",
                    CellState.Sunk => "Zatopiony!",
                    _ => Status
                };

                if (EnemyBoard.Board.AllShipsSunk())
                {
                    Status = "Wygrałeś! Wszystkie statki przeciwnika zostały zatopione.";
                    GameOver = true;
                    return;
                }

                PlayerTurn = false;
                await Task.Delay(1000);
                EnemyTurn();
            }
        }

        private void EnemyTurn()
        {
            if (GameOver) return;

            var rnd = new Random();
            var available = PlayerBoard.GridFlattened.Where(c => c.State != CellState.Hit && c.State != CellState.Miss && c.State != CellState.Sunk).ToArray();
            if (!available.Any()) return;

            var target = available[rnd.Next(available.Length)];
            var result = PlayerBoard.Shoot(target.Row, target.Col);
            Status = result switch
            {
                CellState.Hit => "Przeciwnik trafił!",
                CellState.Miss => "Przeciwnik spudłował!",
                CellState.Sunk => "Przeciwnik zatopił statek!",
                _ => Status
            };
            PlayerTurn = true;

            if (PlayerBoard.Board.AllShipsSunk())
            {
                Status = "Przegrałeś! Wszystkie twoje statki zostały zatopione.";
                GameOver = true;
            }
        }
    }
}
