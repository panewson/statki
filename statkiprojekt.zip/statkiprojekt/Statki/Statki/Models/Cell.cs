﻿namespace Statki.Models
{
    public enum CellState
    {
        Empty,
        Ship,
        Hit,
        Miss,
        Sunk
    }

    public class Cell
    {
        public int Row { get; set; }
        public int Col { get; set; }
        public CellState State { get; set; } = CellState.Empty;
        public Ship? OccupiedShip { get; set; }
    }
}
