﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Statki.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace Statki.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty] private BoardViewModel playerBoard;
        [ObservableProperty] private BoardViewModel enemyBoard;
        [ObservableProperty] private bool playerTurn = true;
        [ObservableProperty] private string status = "Rozmieść statki (kliknij swoją planszę)";

        public MainViewModel()
        {
            PlayerBoard = new BoardViewModel();
            EnemyBoard = new BoardViewModel();
            EnemyBoard.PlaceRandomShips();
        }
    }
}
       /* do dokończenia
        

        private void CellClicked(object? parameter)
        {
            if (parameter is not object[] args || args.Length != 2) return;
            if (args[0] is not int[] position || position.Length != 2) return;
            if (args[1] is not BoardViewModel board) return;

            int row = position[0], col = position[1];

            if (board == EnemyBoard && PlayerTurn)
            {
                var result = EnemyBoard.Shoot(row, col);
                Status = result switch
                {
                    CellState.Hit => "Trafienie!",
                    CellState.Miss => "Pudło!",
                    CellState.Sunk => "Zatopiony!",
                    _ => Status
                };
                PlayerTurn = false;
                _ = Task.Delay(1000).ContinueWith(_ => EnemyTurn());
            }
        }
    }
}
*/